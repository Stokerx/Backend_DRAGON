<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\FunctionSerie;

class FunctionSerieController extends Controller
{

}
